package com.example.a08;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView txtInfo;
    EditText etLastName,etFirstName;
    Button btnSubmit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtInfo = findViewById(R.id.txtInfo);
        etFirstName = findViewById(R.id.etFirstName);
        etLastName = findViewById(R.id.etLastName);
        btnSubmit = findViewById(R.id.btnSubmit);

        btnSubmit.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                String fname = etFirstName.getText().toString();
                String lName = etLastName.getText().toString();

                Intent intent = new Intent(MainActivity.this, SecoundActivity.class);
                intent.putExtra("fname",fname);
                intent.putExtra("lName",lName);

                startActivity(intent);
            }
        });

    }
}