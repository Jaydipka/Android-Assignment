package com.example.studentregistration;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView t1, t2, t3, t4, t5;
    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("First Activity");

        t1=findViewById(R.id.name);
        t2=findViewById(R.id.age);
        t3=findViewById(R.id.address);
        t4=findViewById(R.id.city);
        t5=findViewById(R.id.phonenumber);
        btn=findViewById(R.id.button);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //get data from edit text
                String name = t1.getText().toString();
                String age = t2.getText().toString();
                String address = t3.getText().toString();
                String city = t4.getText().toString();
                String phonenumber = t5.getText().toString();


                Intent intent = new Intent(MainActivity.this, SecoundActivity.class);
                intent.putExtra("Name", name);
                intent.putExtra("Age", age);
                intent.putExtra("Address", address);
                intent.putExtra("City", city);
                intent.putExtra("Phonenumber", phonenumber);
                startActivity(intent);
            }
        });

    }
}